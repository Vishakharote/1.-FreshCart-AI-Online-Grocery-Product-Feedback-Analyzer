import streamlit as st
import pandas as pd
import joblib

# =========================
# PAGE CONFIG
# =========================

st.set_page_config(
    page_title="FreshCart AI",
    page_icon="🛒",
    layout="wide",
    initial_sidebar_state="expanded"
)

# =========================
# LOAD MODEL + DATA
# =========================

model = joblib.load("model/sentiment_model.pkl")
data = pd.read_csv("dataset/grocery_reviews.csv")

# =========================
# CSS
# =========================

st.markdown("""
<style>

.stApp {
    background: #f5f8f4;
}

#MainMenu {
    visibility: hidden;
}

footer {
    visibility: hidden;
}

[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #12372a, #1f5c43);
}

[data-testid="stSidebar"] * {
    color: white !important;
}

.hero {
    background: linear-gradient(135deg, #12372a, #2d7d57);
    padding: 45px;
    border-radius: 25px;
    color: white;
    margin-bottom: 30px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.12);
}

.hero h1 {
    font-size: 45px;
    margin-bottom: 10px;
}

.hero p {
    font-size: 19px;
    color: #e7f5eb;
}

.card {
    background: white;
    padding: 25px;
    border-radius: 20px;
    text-align: center;
    box-shadow: 0 5px 20px rgba(0,0,0,0.07);
    border: 1px solid #e6eee8;
}

.card-number {
    font-size: 32px;
    font-weight: bold;
    color: #17633f;
}

.card-title {
    color: #68756d;
    font-size: 15px;
}

.section-title {
    font-size: 27px;
    font-weight: bold;
    color: #173b2b;
    margin-top: 25px;
}

.review-box {
    background: white;
    padding: 30px;
    border-radius: 22px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.07);
}

.stButton > button {
    background: linear-gradient(90deg, #17633f, #2d8a5d);
    color: white;
    border: none;
    border-radius: 12px;
    padding: 12px 25px;
    font-weight: bold;
}

.stButton > button:hover {
    background: #12372a;
    color: white;
}

textarea {
    border-radius: 15px !important;
}

.footer {
    text-align: center;
    color: #718078;
    padding: 25px;
    font-size: 14px;
}

</style>
""", unsafe_allow_html=True)


# =========================
# SIDEBAR
# =========================

with st.sidebar:

    st.markdown("## 🛒 FreshCart AI")

    st.write("")

    st.markdown("### 📌 Navigation")

    page = st.radio(
        "Go to",
        [
            "🏠 Dashboard",
            "🔍 Review Analyzer",
            "📊 Analytics",
            "🛍️ Products"
        ],
        label_visibility="collapsed"
    )

    st.divider()

    # AI MODEL
    st.markdown("### 🤖 AI Model")

    st.success("✅ Model: Active")

    st.markdown("**Algorithm:**")

    st.markdown("🧠 Multinomial Naive Bayes")

    st.divider()

    st.caption("Online Grocery Product Feedback Analyzer")


# =========================================================
# DASHBOARD
# =========================================================

if page == "🏠 Dashboard":

    st.markdown("""
    <div class="hero">

    <h1>🛒 FreshCart AI</h1>

    <h2>Online Grocery Product Feedback Analyzer</h2>

    <p>
    Understand your customers better using
    Artificial Intelligence & Machine Learning.
    </p>

    </div>
    """, unsafe_allow_html=True)

    total = len(data)
    positive = len(data[data["Sentiment"] == "Positive"])
    negative = len(data[data["Sentiment"] == "Negative"])
    neutral = len(data[data["Sentiment"] == "Neutral"])
    avg_rating = round(data["Rating"].mean(), 1)

    c1, c2, c3, c4 = st.columns(4)

    with c1:
        st.markdown(f"""
        <div class="card">
            <div class="card-number">📋 {total}</div>
            <div class="card-title">Total Reviews</div>
        </div>
        """, unsafe_allow_html=True)

    with c2:
        st.markdown(f"""
        <div class="card">
            <div class="card-number">😊 {positive}</div>
            <div class="card-title">Positive Reviews</div>
        </div>
        """, unsafe_allow_html=True)

    with c3:
        st.markdown(f"""
        <div class="card">
            <div class="card-number">😞 {negative}</div>
            <div class="card-title">Negative Reviews</div>
        </div>
        """, unsafe_allow_html=True)

    with c4:
        st.markdown(f"""
        <div class="card">
            <div class="card-number">⭐ {avg_rating}</div>
            <div class="card-title">Average Rating</div>
        </div>
        """, unsafe_allow_html=True)

    st.write("")

    # AI REVIEW ANALYZER

    st.markdown(
        '<div class="section-title">🔍 AI Review Analyzer</div>',
        unsafe_allow_html=True
    )

    st.write("")

    st.markdown("""
    <div class="review-box">
    <b>Enter customer feedback below.</b><br>
    Our Machine Learning model will identify whether the review is
    Positive, Negative or Neutral.
    </div>
    """, unsafe_allow_html=True)

    st.write("")

    review = st.text_area(
        "Customer Review",
        placeholder="Example: The apples were fresh, sweet and tasty...",
        height=130
    )

    if st.button(
        "✨ Analyze Customer Feedback",
        use_container_width=True
    ):

        if review.strip() == "":
            st.warning("Please enter a customer review.")

        else:

            prediction = model.predict([review])[0]

            new_row = pd.DataFrame({
                "Product_Name": ["Customer Review"],
                "Category": ["Grocery"],
                "Rating": [
                    5 if prediction == "Positive"
                    else 1 if prediction == "Negative"
                    else 3
                ],
                "Feedback": [review],
                "Sentiment": [prediction]
            })

            data = pd.concat(
                [data, new_row],
                ignore_index=True
            )

            data.to_csv(
                "dataset/grocery_reviews.csv",
                index=False
            )

            if prediction == "Positive":
                st.success(
                    "😊 POSITIVE REVIEW — Customer is satisfied!"
                )

            elif prediction == "Negative":
                st.error(
                    "😞 NEGATIVE REVIEW — Customer may not be satisfied."
                )

            else:
                st.info(
                    "😐 NEUTRAL REVIEW — Customer feedback is average."
                )

            st.write("")

            st.markdown(
                '<div class="section-title">📊 Updated Customer Sentiment Graph</div>',
                unsafe_allow_html=True
            )

            sentiment_count = data["Sentiment"].value_counts()

            st.bar_chart(sentiment_count)

            st.success(
                "New review saved successfully! Graph count has been updated."
            )

    else:

        st.write("")

        st.markdown(
            '<div class="section-title">📊 Customer Sentiment Graph</div>',
            unsafe_allow_html=True
        )

        sentiment_count = data["Sentiment"].value_counts()

        st.bar_chart(sentiment_count)


# =========================================================
# REVIEW ANALYZER
# =========================================================

elif page == "🔍 Review Analyzer":

    st.markdown(
        '<div class="section-title">🔍 AI Review Analyzer</div>',
        unsafe_allow_html=True
    )

    st.write("")

    review = st.text_area(
        "Enter Customer Review",
        placeholder="Example: Apple is good and fresh...",
        height=150
    )

    if st.button(
        "✨ Analyze Customer Feedback",
        use_container_width=True
    ):

        if review.strip() == "":
            st.warning("Please enter a review.")

        else:

            prediction = model.predict([review])[0]

            new_row = pd.DataFrame({
                "Product_Name": ["Customer Review"],
                "Category": ["Grocery"],
                "Rating": [
                    5 if prediction == "Positive"
                    else 1 if prediction == "Negative"
                    else 3
                ],
                "Feedback": [review],
                "Sentiment": [prediction]
            })

            data = pd.concat(
                [data, new_row],
                ignore_index=True
            )

            data.to_csv(
                "dataset/grocery_reviews.csv",
                index=False
            )

            if prediction == "Positive":
                st.success("😊 POSITIVE REVIEW")

            elif prediction == "Negative":
                st.error("😞 NEGATIVE REVIEW")

            else:
                st.info("😐 NEUTRAL REVIEW")

            st.write("")

            st.markdown(
                '<div class="section-title">📊 Updated Sentiment Graph</div>',
                unsafe_allow_html=True
            )

            sentiment_count = data["Sentiment"].value_counts()

            st.bar_chart(sentiment_count)


# =========================================================
# ANALYTICS
# =========================================================

elif page == "📊 Analytics":

    st.markdown(
        '<div class="section-title">📊 Customer Feedback Analytics</div>',
        unsafe_allow_html=True
    )

    st.write("")

    col1, col2 = st.columns(2)

    with col1:

        st.markdown("### 📈 Sentiment Analysis")

        sentiment_count = data["Sentiment"].value_counts()

        st.bar_chart(sentiment_count)

    with col2:

        st.markdown("### ⭐ Rating Analysis")

        rating_count = data["Rating"].value_counts().sort_index()

        st.bar_chart(rating_count)

    st.divider()

    st.markdown(
        '<div class="section-title">🥬 Product Categories</div>',
        unsafe_allow_html=True
    )

    category_count = data["Category"].value_counts()

    st.bar_chart(category_count)


# =========================================================
# PRODUCTS
# =========================================================

elif page == "🛍️ Products":

    st.markdown(
        '<div class="section-title">🛍️ Grocery Products & Reviews</div>',
        unsafe_allow_html=True
    )

    st.write("")

    st.dataframe(
        data[
            [
                "Product_Name",
                "Category",
                "Rating",
                "Feedback",
                "Sentiment"
            ]
        ],
        use_container_width=True,
        hide_index=True
    )


# =========================================================
# FOOTER
# =========================================================

st.markdown("""
<div class="footer">

🛒 <b>FreshCart AI</b><br>
Online Grocery Product Feedback Analyzer<br><br>
Built using Python • Streamlit • Machine Learning

</div>
""", unsafe_allow_html=True)