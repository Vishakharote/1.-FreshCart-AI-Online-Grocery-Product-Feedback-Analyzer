import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
import joblib

# Load dataset
data = pd.read_csv("dataset/grocery_reviews.csv")

# Separate input and output
X = data["Feedback"]
y = data["Sentiment"]

# Create machine learning model
model = Pipeline([
    ("tfidf", TfidfVectorizer()),
    ("classifier", MultinomialNB())
])

# Train the model
model.fit(X, y)

# Save the trained model
joblib.dump(model, "model/sentiment_model.pkl")

print("Model trained successfully!")
print("Model saved successfully!")